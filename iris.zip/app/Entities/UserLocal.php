<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class UserLocal extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'app_user_local';
}

<div class="card-tools">
    <button class="btn btn-tool" data-card-widget="collapse">
        <i class="fas fa-plus"></i>
    </button>
</div><?php /**PATH D:\WORKINGDESK\OTHER_PROJECT\iris\resources\views/components/html/card-collapse.blade.php ENDPATH**/ ?>
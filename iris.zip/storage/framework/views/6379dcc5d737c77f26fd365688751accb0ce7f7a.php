<?php $__env->startSection('title', 'Show Evaluasi'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card card-success">
        <div class="card-body">
            <?php echo e(Form::fgText('Judul Riset', 'user_id', $data->risettitle, ['class' => 'form-control', 'disabled'], null, 'text', true)); ?>

            <?php echo e(Form::fgText('Unit Kerja Penilai', 'filearchive_id', $data->unitkerja->nama, ['class' => 'form-control', 'disabled'], null, 'text', true)); ?>

            <?php echo e(Form::fgText('Seberapa puaskah anda terhadap kualitas riset?', 'risetquality', $data->risetquality, ['class' => 'form-control', 'disabled'], null, 'text', true)); ?>


            <table class="table table-striped tablesaw" data-tablesaw-mode="stack">
                <thead>
                    <tr>
                        <th>Aspek yang perlu ditingkatkan</th>
                        <th>Penjelasan dan saran</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($data->evaluasidetail)): ?>
                        <?php $__currentLoopData = $data->evaluasidetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->aspect); ?></td>
                                <td><?php echo e($item->description); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr><td colspan="2">No Record(s) found</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer clearfix">
            <?php echo e(Form::fgFormButton('evaluasi', 'show')); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WORKINGDESK\OTHER_PROJECT\iris\app\Modules\Evaluasi\Providers/../views/show.blade.php ENDPATH**/ ?>
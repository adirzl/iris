<?php
$segment = request()->segment(2);
$title = 'create'; $method = 'post'; $action = 'kelola-artikel.store';
if ($segment !== 'create' ) { $title = 'edit'; $method = 'put'; $action = ['kelola-artikel.update', $kelola_artikel->id]; }
?>

<?php $__env->startSection('title', __('label.' . $title) . ' Kelola - Artikel'); ?>
<?php $__env->startSection('content'); ?>
<?php echo e(Form::open(['route' => $action, 'method' => $method, 'class' => 'form-horizontal form-data', 'autocomplete' => 'off', 'files' => true])); ?>

<div class="card card-success">
    <div class="card-body">
        <?php echo e(Form::fgText('Title', 'title', $kelola_artikel->title, ['class' => 'form-control'], null, 'text', true)); ?>

        <?php echo e(Form::fgText('Description', 'description', $kelola_artikel->description, ['class' => 'form-control', 'cols' => '20', 'rows' => '5'], null, 'textarea', true)); ?>

        <div class="form-group row">
            <label for="" class="col-md-2 col-form-label">Upload Image</label>
            <?php if(isset($kelola_artikel->image)): ?>
            <div class="col-md-5 text-left">
                <img src="<?php echo e(asset('artikel/' . $kelola_artikel->image)); ?>" alt="logo" width="500" height="200" style="margin-top: 0%">
            </div>
            <?php endif; ?>
            <div class="col-md-<?php echo e(isset($kelola_artikel->image) ? '5' : '10'); ?>">
                <?php echo Form::file($image, ['class' => 'form-control dropify']); ?>

            </div>
        </div>
        
        <?php echo e(Form::fgSelect('Status', 'status', to_dropdown($status_artikel), $kelola_artikel->status, ['class' => 'form-control'], null, true)); ?>

    </div>

    <div class="card-footer clearfix">
        <?php echo e(Form::fgFormButton('kelola-artikel', $segment)); ?>

    </div>
</div>
<?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WORKINGDESK\OTHER_PROJECT\iris\app\Modules\Kelola\Providers/../views/artikel/form.blade.php ENDPATH**/ ?>
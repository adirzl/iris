<a href="<?php echo e(url('/')); ?>" class="brand-link">
    <span class="brand-image"><?php echo e(config('app.name')); ?></span>
    <span class="brand-text font-weight-light"><?php echo e(config('app.display_name')); ?></span>
</a>

<div class="sidebar">
    <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
            <li class="nav-item">
                <a href="<?php echo e(url('/home')); ?>" class="nav-link <?php echo e(isHome()); ?>" rel="page-content">
                    <i class="nav-icon fa fa-home"></i>
                    <p>Home</p>
                </a>
            </li>
            <?php echo Navbar::render(); ?>

        </ul>
    </nav>
</div><?php /**PATH D:\WORKINGDESK\OTHER_PROJECT\iris\resources\views/layouts/partials/navbar.blade.php ENDPATH**/ ?>
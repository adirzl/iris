<?php echo e(Form::open(['url' => '/kuisioner-pertanyaan/filter', 'method' => 'post', 'class' => 'form-horizontal form-filter', 'role' => 'form', 'autocomplete' => 'off'])); ?>

    <div class="card card-teal collapsed-card">
        <div class="card-header">
            <h3 class="card-title"><?php echo e(__('label.filter')); ?></h3>
            <?php echo Html::cardCollapse(); ?>

        </div>

        <div class="card-body">
            <div class="row">
                <div class="col-md-4">
                    <?php echo e(Form::fgText('Description', 'description', request()->title, ['class' => 'form-control'])); ?>

                </div>

                <div class="col-md-4">
                    <?php echo e(Form::fgSelect('Status', 'status', to_dropdown($status_pertanyaan), request()->status, ['class' => 'form-control'])); ?>

                </div>

                <div class="col-md-4">
                    <?php echo e(Form::fgSelect('Kategori User', 'status_user', to_dropdown($status_user), request()->status_user, ['class' => 'form-control'])); ?>

                </div>
            </div>
        </div>

        <div class="card-footer">
            <?php echo e(Form::fgFilterButton()); ?>

        </div>
    </div>
<?php echo e(Form::close()); ?>

<?php /**PATH D:\WORKINGDESK\OTHER_PROJECT\iris\app\Modules\Kuisioner\Providers/../views/pertanyaan/filter.blade.php ENDPATH**/ ?>
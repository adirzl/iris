
<?php $__env->startSection('title', 'Kuisioner - Pertanyaan'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('kuisioner::pertanyaan.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(count($data)): ?>
        <div class="card card-success">
            <div class="card-body">
                <table class="table table-striped tablesaw" data-tablesaw-mode="stack">
                    <thead>
                    <tr>
                        <th><?php echo e(__('label.action')); ?></th>
                        <th>Description</th>
                        <th>Tgl Dibuat</th>
                        <th>Tgl Diubah</th>
                        <th>User</th>
                        <th>Status</th>
                    </tr> 
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo Html::linkResource('kuisioner-pertanyaan', ['id' => $d->id, 'label' => $d->description]); ?>  
                            </td>
                            <td><?php echo e($d->description); ?></td>
                            <td><?php echo e($d->created_at); ?></td>
                            <td><?php echo e($d->updated_at); ?></td>
                            <td><?php echo e($d->status_user !== '-' ? $status_user[$d->status_user] : $d->status_user); ?></td>
                            <td><span class="badge bg-<?php echo e($d->status == 1 ? 'success' : 'danger'); ?>"><?php echo e($d->status !== '-' ? $status_pertanyaan[$d->status] : $d->status); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="card-footer clearfix">
                <div class="row">
                    <div class="col-6">
                        <?php echo e($data->appends(\Illuminate\Support\Arr::except(request()->input(), '_token'))->setPath(url('kuisioner-pertanyaan'))->links()); ?>

                    </div>

                    <div class="col-6 text-right">
                        <?php echo Html::linkCreate('kuisioner-pertanyaan'); ?>

                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-warning">
            <?php echo trans('label.no_data_with_link', ['label' => 'Kuisioner - Pertanyaan', 'uri' => route('kuisioner-pertanyaan.create')]); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WORKINGDESK\OTHER_PROJECT\iris\app\Modules\Kuisioner\Providers/../views/pertanyaan/default.blade.php ENDPATH**/ ?>
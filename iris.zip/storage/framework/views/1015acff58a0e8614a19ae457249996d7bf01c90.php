<div class="form-group <?php echo e($layout ? 'row' : ''); ?>">
    <?php if($layout): ?>
        <label for="" class="col-md-3 col-form-label"><?php echo e($label); ?></label>
        <div class="col-md-9">
            <?php echo e(Form::$type($name, $value, $attributes)); ?>

            <?php if(!is_null($help)): ?>
                <small class="form-text text-muted"><?php echo e($help); ?></small>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <label for=""><?php echo e($label); ?></label>
        <?php echo e(Form::$type($name, $value, $attributes)); ?>

        <?php if(!is_null($help)): ?>
            <small class="form-text text-muted"><?php echo e($help); ?></small>
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php /**PATH D:\WORKINGDESK\OTHER_PROJECT\iris\resources\views/components/form/text.blade.php ENDPATH**/ ?>
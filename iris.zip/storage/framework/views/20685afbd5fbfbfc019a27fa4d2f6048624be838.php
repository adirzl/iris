
<?php $__env->startSection('title', 'Kelola - Banner'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('kelola::banner.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(count($data)): ?>
        <div class="card card-success">
            <div class="card-body">
                <table class="table table-striped tablesaw" data-tablesaw-mode="stack">
                    <thead>
                    <tr>
                        <th><?php echo e(__('label.action')); ?></th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Image</th>
                        <th>Status</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo Html::linkResource('kelola-banner', ['id' => $d->id, 'label' => $d->title]); ?>  
                            </td>
                            <td><?php echo e($d->title); ?></td>
                            <td><?php echo e($d->description); ?></td>
                            <td><img src="<?php echo e(asset('banner/' . $d->image)); ?>" alt="logo" width="200" height="100" style="margin-top: 0%"></td>
                            <td><span class="badge bg-<?php echo e($d->status == 1 ? 'success' : 'danger'); ?>"><?php echo e($d->status !== '-' ? $status_banner[$d->status] : $d->status); ?></span></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="card-footer clearfix">
                <div class="row">
                    <div class="col-6">
                        <?php echo e($data->appends(\Illuminate\Support\Arr::except(request()->input(), '_token'))->setPath(url('kelola-banner'))->links()); ?>

                    </div>

                    <div class="col-6 text-right">
                        <?php echo Html::linkCreate('kelola-banner'); ?>

                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-warning">
            <?php echo trans('label.no_data_with_link', ['label' => 'Kelola - Banner', 'uri' => route('kelola-banner.create')]); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WORKINGDESK\OTHER_PROJECT\iris\app\Modules\Kelola\Providers/../views/banner/default.blade.php ENDPATH**/ ?>
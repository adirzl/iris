<?php $__env->startSection('content'); ?>

    <?php if($unitkerja): ?>
        <section id="page-title">
            <div class="container clearfix">
                <h1><?php echo e(strtoupper($unitkerja->name)); ?></h1>
                <span>Deskripsi singkat judul</span>
            </div>
        </section>
        <section id="content">
            <div class="content-wrap">
                <div class="container clearfix">

                    <div class="row">
                        <div class="postcontent col-lg-9">
                            THIS IS MAIN CONTENT
                            <ul>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($item->name); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>

                        <div class="sidebar col-lg-3">
                            <div class="sidebar-widgets-wrap">
                                <div class="widget clearfix">
                                    <?php echo e(Form::text('keyword', null, [ 'class' => 'asdf', 'id' => 'keyword' ])); ?>

                                    <button>Cari</button>
                                    <h4>File Type</h4>
                                    <?php $__currentLoopData = $fileType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <ul>
                                            <li><?php echo e(Form::checkbox('fileType', true, null)); ?> <?php echo e($item->name); ?></li>
                                        </ul>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WORKINGDESK\OTHER_PROJECT\iris\resources\views/landing/detail.blade.php ENDPATH**/ ?>
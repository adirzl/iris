<?php $__env->startSection('title', 'Request File'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card card-success">
        <div class="card-body">
            <?php echo e(Form::fgText('User', 'user_id', $data->user->profile->nama, ['class' => 'form-control', 'disabled'], null, 'text', true)); ?>

            <?php echo e(Form::fgText('File', 'filearchive_id', $data->filearchive->filetype->name, ['class' => 'form-control', 'disabled'], null, 'text', true)); ?>

            <?php echo e(Form::fgText('Description', 'description', $data->description, ['class' => 'form-control', 'disabled'], null, 'textarea', true)); ?>

        </div>
    </div>

    <?php echo e(Form::open(['route' => ['requestfile.storeapproval', $data->id], 'method' => 'post', 'class' => 'form-horizontal form-data', 'autocomplete' => 'off'])); ?>

    <div class="card card-success">
        <div class="card-body">
            <?php echo e(Form::fgSelect('Approval', 'status', to_dropdown($approval), null, ['class' => 'form-control'], null, true)); ?>

            <div class="form-group row">
                <label for="" class="col-md-2 col-form-label">Alasan</label>
                <div class="col-md-10">
                    <?php echo e(Form::textarea('alasan_tolak', null, ['class' => 'form-control'])); ?>

                </div>
            </div>
        </div>

        <div class="card-footer clearfix">
            <?php echo e(Form::fgFormButton('requestfile')); ?>

        </div>
    </div>
    <?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WORKINGDESK\OTHER_PROJECT\iris\app\Modules\RequestFile\Providers/../views/approval.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Request File'); ?>
<?php $__env->startSection('content'); ?>
    
    <?php if(count($data)): ?>
        <div class="card card-success">
            <div class="card-body">
                <table class="table table-striped tablesaw" data-tablesaw-mode="stack">
                    <thead>
                    <tr>
                        <th><?php echo e(__('label.action')); ?></th>
                        <th>User</th>
                        <th>File</th>
                        <th>Description</th>
                        <th>Status</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php
                                    $actions = null;
                                    $actions = [
                                        [
                                            'url' => 'requestfile.approval', 'permission' => 'approval requestfile', 'attributes' => [
                                                'rel' => 'content', 'title' => __('label.approval_message', ['label' => $d->created_at])
                                            ], 'label' => __('label.approve_message', ['label' => $d->user->profile->nama]),
                                        ],
                                    ];
                                ?>
                                <?php echo Html::linkActions($actions, $d->id); ?>

                            </td>
                            <td><?php echo e($d->user->profile->nama); ?></td>
                            <td><?php echo e($d->filearchive->filetype->name); ?></td>
                            <td><?php echo e($d->description); ?></td>
                            <td><?php echo e(isset($d->status) ? $status_requestfile[$d->status] : ''); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="card-footer clearfix">
                <div class="row">
                    <div class="col-6">
                        <?php echo e($data->appends(\Illuminate\Support\Arr::except(request()->input(), '_token'))->setPath(url('requestfile'))->links()); ?>

                    </div>

                    <div class="col-6 text-right">
                        <?php echo Html::linkCreate('requestfile'); ?>

                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-warning">
            <?php echo trans('label.no_data_with_link', ['label' => 'Request File', 'uri' => route('requestfile.create')]); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WORKINGDESK\OTHER_PROJECT\iris\app\Modules\RequestFile\Providers/../views/default.blade.php ENDPATH**/ ?>
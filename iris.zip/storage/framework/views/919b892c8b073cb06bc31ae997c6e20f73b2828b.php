<?php echo e(Form::open(['url' => '/opsi/filter', 'method' => 'post', 'class' => 'form-horizontal form-filter', 'role' => 'form', 'autocomplete' => 'off'])); ?>

    <div class="card card-teal collapsed-card">
        <div class="card-header">
            <h3 class="card-title"><?php echo e(__('label.filter')); ?></h3>
            <?php echo Html::cardCollapse(); ?>

        </div>

        <div class="card-body">
            <div class="col-md-12">
                <?php echo e(Form::fgText('Nama Opsi', 'name', request()->name, ['class' => 'form-control'], null, 'text', true)); ?>

            </div>
        </div>

        <div class="card-footer">
            <?php echo e(Form::fgFilterButton()); ?>

        </div>
    </div>
<?php echo e(Form::close()); ?>

<?php /**PATH D:\WORKINGDESK\OTHER_PROJECT\iris\app\Modules\Opsi\Providers/../views/filter.blade.php ENDPATH**/ ?>
<button class="btn btn-primary btn-sm">
    <i class="fa fa-search"></i> <?php echo e(__('button.filter')); ?>

</button>&nbsp;
<button type="reset" class="btn btn-warning btn-sm filter-reset">
    <i class="fa fa-redo"></i> <?php echo e(__('button.reset')); ?>

</button><?php /**PATH D:\WORKINGDESK\OTHER_PROJECT\iris\resources\views/components/form/filter.blade.php ENDPATH**/ ?>
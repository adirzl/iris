
<?php $__env->startSection('title', 'Kuisioner - Penilaian'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('kuisioner::penilaian.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(count($data)): ?>
<div class="card card-success">
    <div class="card-body">
        <table class="table table-striped tablesaw" data-tablesaw-mode="stack">
            <thead>
                <tr>
                    <th><?php echo e(__('label.action')); ?></th>
                    <th>Nama Perusahaan</th>
                    <th>User</th>
                    <th>Periode</th>
                    <th>Tanggal</th>
                    <th>Kategori</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo Html::linkShow('kuisioner-penilaian', ['id' => $d->id, 'label' =>$d->get_company_name->company_name . ' - Triwulan ' . $d->periode . ' - ' . substr($d->created_at,0,4) ]); ?>  
                    </td>
                    <td><?php echo e($d->get_company_name->company_name); ?></td>
                    <td><?php echo e($d->user); ?></td>
                    <td><?php echo e($d->periode !== '-' ? $periode[$d->periode] : $d->periode); ?> - <?php echo e(substr($d->created_at,0,4)); ?></td>
                    <td><?php echo e($d->created_at); ?></td>
                    <td><span class="badge bg-<?php echo e($d->status_kuisioner == 1 ? 'primary' : 'success'); ?>"><?php echo e($d->status_kuisioner !== '-' ? $status_kuisioner[$d->status_kuisioner] : $d->status_kuisioner); ?></span></td>
                    <td>
                        <?php if($d->status == 1): ?>
                        <span class="badge bg-warning">Draft</span>
                    <?php elseif($d->status == 2): ?>
                        <span class="badge bg-success">Approved</span>
                    <?php else: ?>
                        <span class="badge bg-danger">Reject</span>
                    <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="card-footer clearfix">
        <div class="row">
            <div class="col-6">
                <?php echo e($data->appends(\Illuminate\Support\Arr::except(request()->input(), '_token'))->setPath(url('kuisioner-penilaian'))->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php else: ?>
<div class="alert alert-warning">
    Data Belum Tersedia, LJK Belum Mengisi
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WORKINGDESK\OTHER_PROJECT\iris\app\Modules\Kuisioner\Providers/../views/penilaian/default.blade.php ENDPATH**/ ?>
<footer class="main-footer">
    <strong><?php echo config('app.copyright') ? config('app.copyright') : 'Copyright &copy; 2019.'; ?></strong>
</footer><?php /**PATH D:\WORKINGDESK\OTHER_PROJECT\iris\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>
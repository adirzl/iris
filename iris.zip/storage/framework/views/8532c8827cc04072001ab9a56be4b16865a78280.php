<?php
    $segment = request()->segment(2);
    $title = 'create'; $method = 'post'; $action = 'kuisioner-pertanyaan.store';
    if ($segment !== 'create' ) { $title = 'edit'; $method = 'put'; $action = ['kuisioner-pertanyaan.update', $kuisioner_pertanyaan->id]; }
?>

<?php $__env->startSection('title', __('label.' . $title) . ' Kuisioner - Pertanyaan'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo e(Form::open(['route' => $action, 'method' => $method, 'class' => 'form-horizontal form-data', 'autocomplete' => 'off'])); ?>

    <div class="card card-success">
        <div id="kuisioner_manrisk" class="card-body">
            <?php echo e(Form::fgSelect('Kategori User', 'status_user', to_dropdown($status_user), $kuisioner_pertanyaan->status_user, ['id' => 'leave', 'class' => 'form-control', 'onchange' => 'leaveChange()'], null, true)); ?>

            <?php echo e(Form::fgText('Ketegori Pertanyaan', 'description', $kuisioner_pertanyaan->description, ['class' => 'form-control', 'placeholder' => 'Deskripsi'], null, 'text', true)); ?>

                <div class="form-group row">
                    <label id="message" class="col-md-2 col-form-label">Pertanyaan</label>
                    <div class="col-md-10">
                        <?php if($kuisioner_pertanyaan->detail_pertanyaan->count()): ?>
                            <?php $__currentLoopData = $kuisioner_pertanyaan->detail_pertanyaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="options" id="options<?php echo e($loop->iteration); ?>">
                                <div class="row" style="margin-bottom:8px">
                                    <div class="col-sm-8">
                                            <?php echo e(Form::hidden('id[]', $v->id)); ?>

                                            <?php echo e(Form::textarea('pertanyaan[]', $v->pertanyaan, ['class' => 'form-control', 'placeholder' => 'Pertanyaan', 'rows' => 3, 'cols' => 15])); ?>

                                        </div>

                                        <div class="col-sm-2">
                                            <a href="javascript:void(0);" class="btn btn-sm btn-info m-r-5 add" id="add<?php echo e($loop->iteration); ?>">
                                                <i class="fa fa-plus"></i>
                                            </a>&nbsp;
                                            <a href="javascript:void(0);" class="btn btn-sm btn-danger rmv" id="rmv<?php echo e($loop->iteration); ?>">
                                                <i class="fa fa-minus"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="options" id="options0">
                                <div class="row" style="margin-bottom:8px">
                                    <div class="col-sm-8">
                                        <?php echo e(Form::hidden('id[]', null)); ?>

                                        <?php echo e(Form::textarea('pertanyaan[]', null, ['class' => 'form-control', 'placeholder' => 'Pertanyaan', 'rows' => 3, 'cols' => 15])); ?>

                                    </div>

                                    <div class="col-sm-2">
                                        <a href="javascript:void(0);" class="btn btn-sm btn-info m-r-5 add" id="add0">
                                            <i class="fa fa-plus"></i>
                                        </a>&nbsp;
                                        <a href="javascript:void(0);" class="btn btn-sm btn-danger rmv" id="rmv0">
                                            <i class="fa fa-minus"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php echo e(Form::fgSelect('Status', 'status', to_dropdown($status_pertanyaan), $kuisioner_pertanyaan->status, ['class' => 'form-control'], null, true)); ?>

            </div>
            <div class="card-footer clearfix">
                <?php echo e(Form::fgFormButton('kuisioner-pertanyaan', $segment)); ?>

            </div>
        </div>
    <?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WORKINGDESK\OTHER_PROJECT\iris\app\Modules\Kuisioner\Providers/../views/pertanyaan/form.blade.php ENDPATH**/ ?>
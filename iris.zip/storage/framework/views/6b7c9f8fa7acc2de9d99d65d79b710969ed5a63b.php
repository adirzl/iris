<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/app.css', request()->isSecure())); ?>" nonce="<?php echo e(csp_nonce()); ?>">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic" nonce="<?php echo e(csp_nonce()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?> :: <?php echo e(config('app.display_name')); ?></title>
</head>

<body class="hold-transition login-page" style="background-image: url(../img/wallpaper_iris.png);">
    <div class="login-box" style="margin-right: 1000px;
    margin-bottom: 150px;">
        <div class="login-logo">
            <!-- <img src="<?php echo e(asset('img/logo.png')); ?>" alt="" width="140" height="80"> -->
            <h4 style="font-size: 40px; color:#ffcc56;"><strong><?php echo e(config('app.display_name')); ?></strong></h4>
        </div>

        <?php echo $__env->make('layouts.partials.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="card">
            <div class="vard-body login-card-body">
                <p class="login-box-msg"><?php echo $__env->yieldContent('title'); ?></p>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('js/app.js', request()->isSecure())); ?>" nonce="<?php echo e(csp_nonce()); ?>"></script>
</body>

</html><?php /**PATH D:\WORKINGDESK\OTHER_PROJECT\iris\resources\views/layouts/auth.blade.php ENDPATH**/ ?>
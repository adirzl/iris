<?php $__env->startSection('title', 'Evaluasi'); ?>
<?php $__env->startSection('content'); ?>
    
    <?php if(count($data)): ?>
        <div class="card card-success">
            <div class="card-body">
                <table class="table table-striped tablesaw" data-tablesaw-mode="stack">
                    <thead>
                    <tr>
                        <th><?php echo e(__('label.action')); ?></th>
                        <th>Judul Riset</th>
                        <th>Unit Kerja Penilai</th>
                        <th>Created at</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php
                                    $actions = null;
                                    $actions = [
                                        [
                                            'url' => 'evaluasi.show', 'permission' => 'show evaluasi', 'attributes' => [
                                                'rel' => 'content', 'title' => __('label.show_message', ['label' => $d->risettitle])
                                            ], 'label' => __('label.show_message', ['label' => $d->risettitle]),
                                        ],
                                    ];
                                ?>
                                <?php echo Html::linkActions($actions, $d->id); ?>

                            </td>
                            <td><?php echo e($d->risettitle); ?></td>
                            <td><?php echo e($d->unitkerja->nama); ?></td>
                            <td><?php echo e($d->created_at); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="card-footer clearfix">
                <div class="row">
                    <div class="col-6">
                        <?php echo e($data->appends(\Illuminate\Support\Arr::except(request()->input(), '_token'))->setPath(url('requestfile'))->links()); ?>

                    </div>

                    <div class="col-6 text-right">
                        <?php echo Html::linkCreate('requestfile'); ?>

                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-warning">
            <?php echo trans('label.no_data_with_link', ['label' => 'Request File', 'uri' => route('requestfile.create')]); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WORKINGDESK\OTHER_PROJECT\iris\app\Modules\Evaluasi\Providers/../views/default.blade.php ENDPATH**/ ?>